from greet import greet

def main(args):
    return greet(args)
